package com.nit.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nit.cart.Cart;

public interface CartRespository extends JpaRepository<Cart, Integer> {
   public Cart findByCustomerCid(Integer cid);
}
