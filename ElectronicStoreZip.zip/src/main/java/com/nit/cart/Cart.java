package com.nit.cart;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.DoubleStream;

import com.nit.entity.Customer;
import com.nit.entity.Product;

import jakarta.annotation.Generated;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@Table(name="cart")
@AllArgsConstructor
@RequiredArgsConstructor
@NoArgsConstructor
public class Cart {
	
	
	@Id
	@SequenceGenerator(name ="gen1",sequenceName = "cart_seq",initialValue = 1,allocationSize = 5000)
	
	@GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE )
	private Integer id;
	
	@OneToOne
	@JoinColumn(name="customer_id",referencedColumnName ="cid" )
	@NonNull
	private Customer customer;
	
	@OneToMany(mappedBy = "cart",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<CartItem> items=new ArrayList<>();
	
	private Double totalPrice;
	
	private Integer totalQuantity;
	
	public void additem(Product product,int quantity) {
		CartItem item=items.
				stream()
				.filter(
						i->i.getProduct().getId().equals(product.getId()))
				.findFirst().orElseGet(
						()->{
					CartItem it=new CartItem();
					it.setCart(this);
					it.setPrice(product.getPprice());
					it.setProduct(product);
					it.setQuantity(quantity);
					items.add(it);
					return it;
					
				});
		item.setQuantity(item.getQuantity()+quantity);
		item.setSubTotal(item.getQuantity()*item.getPrice());
		recalc();
	}
	public void removeItem(Integer id) {
		items.removeIf(
				i->i.getProduct().getId().equals(id));
		recalc();
		
	}
	public void updateItemQuantity(Long Id,int newqty) {
		items.stream().filter(
				i->i.getProduct().
				getId().equals(Id)).
		findFirst().
		ifPresent(
						i->{i.setQuantity(newqty);
						i.setSubTotal(newqty*i.getPrice());
						});
		recalc();
				
	}
	
	public void recalc() {
		totalPrice=items.stream().mapToDouble(CartItem::getSubTotal).sum();
	  totalQuantity=items.stream().mapToInt(CartItem::getQuantity).sum();
	}
	
	

}
