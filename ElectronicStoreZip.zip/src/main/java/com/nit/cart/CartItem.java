package com.nit.cart;

import com.nit.entity.Product;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Table(name="cartitem")
@Entity
@NoArgsConstructor
public class CartItem {
	
	
	@Id
	@SequenceGenerator(name ="gen1",sequenceName = "cartitem_seq",initialValue = 1,allocationSize = 5000)
	
	@GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE )
	private Long id;
	
	@ManyToOne
	@JoinColumn(name="cart_id")
	private Cart cart;
	
	
	@ManyToOne
	@JoinColumn(name="product_id")
	private Product product;
	
	private Integer quantity;
	
	private Double price;
	private Double subTotal;

}
