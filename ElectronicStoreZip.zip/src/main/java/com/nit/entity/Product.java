package com.nit.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="prod_tab")
public class Product {
	
	@Id
	@SequenceGenerator(name="gen",allocationSize = 1,initialValue = 1,sequenceName = "prod_id")
	@GeneratedValue(generator ="gen",strategy = GenerationType.SEQUENCE)
	private Integer id;
	
	private Integer pcode;
	private String pname;
	private String pcompany;
	private double pprice;
	private Integer pqty;
	 private String imageUrl;
	

}
