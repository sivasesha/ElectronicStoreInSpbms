package com.nit.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="admin_tab")
public class Admin {
	
	@Id
	private Integer id;
	private String uname;
	private String pwrd;
	private String fname;
	private String lname;
	private String gender;
	private String email;
	private Integer age;
	private String addrs;
	

}
