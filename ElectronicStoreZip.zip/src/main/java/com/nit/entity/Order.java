package com.nit.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="order_tab")
public class Order {
	
	@Id
	@SequenceGenerator(name="gen",allocationSize = 1,initialValue = 1,sequenceName = "order_id")
	@GeneratedValue(generator ="gen",strategy = GenerationType.SEQUENCE)
	private Integer orderid;
	private Integer pcode;
	private String pname;
	private double pprice;
	private double totalAmount;
	private String pcompany;
	private LocalDate ordereddate;
	private Integer pqty;
	private Integer Pavailableqty;
	
	
	

}
