package com.nit.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="Customer_tab")
public class Customer {
	
	@Id
	@SequenceGenerator(name="gen",allocationSize = 1,initialValue = 1,sequenceName = "prod_id")
	@GeneratedValue(generator ="gen",strategy = GenerationType.SEQUENCE)
	private Integer cid;
	private String cfname;
	private String clname;
	private String cuname;
	private String cpwrd;
	private String cmail;
	
	

}
