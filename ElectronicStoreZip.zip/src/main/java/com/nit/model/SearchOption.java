package com.nit.model;

import lombok.Data;

@Data
public class SearchOption {
	
	private String name;
	private String company;
	private Double minprice;
	private Double maxprice;

}
