package com.nit.controller;

import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.nit.cart.Cart;
import com.nit.entity.Customer;
import com.nit.entity.Product;
import com.nit.service.ICartService;
import com.nit.service.ICustomerService;

import jakarta.servlet.http.HttpSession;

@Controller
public class ElectronicStoreController {
	
	@Autowired
	private ICustomerService service;
	
	@Autowired
	private ICartService cartService;
	

	
	@GetMapping("/home")
	public String homepage() {
		return"home";
	}
	@GetMapping("/")
	public String welcomePage() {
		System.out.println("ElectronicStoreController.welcomePage()");
		return"home";
	}
	
	@GetMapping("/welcome")
	public String welcomePageAdmin() {
		System.out.println("ElectronicStoreController.welcomePageAdmin()");
		return"Welcome";
	}
	@GetMapping("/CustomerFirst")
	public String welcomePageAdmins() {
		System.out.println("ElectronicStoreController.welcomePageAdmins()");
		return"CustomerFirst";
	}
	
	@GetMapping("/customerLogin")
	public String CustomerLogin(Model model) {
		System.out.println("ElectronicStoreController.CustomerLogin()");
		model.addAttribute("customer",new Customer());
		return"customerLogin";
	}
	
	
	@PostMapping("customerLogin")
	public String validateCustomerUser(@ModelAttribute("customer")Customer customer,Model model,HttpSession session) {
		
		if(customer.getCuname()==null||customer.getCuname().isEmpty()||customer.getCpwrd()==null||customer.getCpwrd().isEmpty()) {
			model.addAttribute("customerMsg","Please Enter Valid Credentails");
			 return "customerLogin";
		}
		Optional<Customer> cust=service.validateUser(customer.getCuname(), customer.getCpwrd());
		model.addAttribute("name", customer.getCfname());
		if(cust.isPresent()) {
			session.setAttribute("role","CUSTOMER");
			session.setAttribute("username", customer.getCuname());
			return"redirect:/home";
		}
		else {
			model.addAttribute("customerMsg","invalid username and Password");
			return"customerLogin";
		}
	}
	
	
	@GetMapping("/customer")
	public String CustomerReg(Model model) {
		System.out.println("ElectronicStoreController.CustomerReg()");
		model.addAttribute("customer",new Customer());
		return"customer";
	}
				
	@PostMapping("/customer")
	public String Customerregister(@ModelAttribute("customer") Customer customer) {
		System.out.println("ElectronicStoreController.Customerregister()");
		service.RegisterCustomer(customer);
		return"Sucess";
	}
	
	@GetMapping("/customerView")
	public String showproducts(Map<String, Object> map, HttpSession session) {
	    if (!"CUSTOMER".equals(session.getAttribute("role"))) {
	        return "redirect:/home";
	    }

	    Iterable<Product> products = service.showAllData();
	    map.put("products", products);

	    String username = (String) session.getAttribute("username");
	    Customer customer = service.getCustomerByUsername(username);
	    map.put("customer", customer);

	    Cart cart = cartService.getCartByCustomerId(customer.getCid());
	    map.put("cart", cart);

	    // Create a typed Map<Integer,Integer> for cart items
	    Map<Integer, Integer> cartItems = cart.getItems().stream()
	            .collect(Collectors.toMap(
	                    item -> item.getProduct().getId(), // correct method
	                    item -> item.getQuantity(),        // correct method
	                    (existing, replacement) -> existing
	            ));


	    map.put("cartItems", cartItems);

	    return "customerView";
	}

	
}
