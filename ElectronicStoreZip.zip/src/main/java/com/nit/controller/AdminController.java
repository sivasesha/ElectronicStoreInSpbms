package com.nit.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nit.entity.Admin;
import com.nit.entity.Product;
import com.nit.service.IAdminService;
import com.nit.service.IProdServImpl;

import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {
    
	@Autowired
	private IAdminService adminserv;
	
	
	@GetMapping("/admin")
	public String adminLoginPage(Model model) {
		System.out.println("ElectronicStoreController.adminLoginPage()");
		model.addAttribute("admin",new Admin());
		return"admin";
	}

	@PostMapping("/admin")
	public String processAdminlogin(@ModelAttribute("admin") Admin admin,Model model,HttpSession session) {
		Optional<Admin> res=adminserv.validateAdmin(admin.getUname(), admin.getPwrd());
		model.addAttribute("name",admin.getUname());
		if(res.isPresent()) {
			session.setAttribute("role","ADMIN");
			session.setAttribute("username", admin.getUname());
			return"redirect:/home";
		}else {
			model.addAttribute("eror","invalid username and Password");
			return"admin";
		}	
	}
	/*
	@GetMapping("/AdminHome")
	public String adminHome(Model model) {
		System.out.println("AdminController.adminHome()");
		return"AdminHome";
	}
	*/
	@GetMapping("/logout")
	public String  logoutAdmin(HttpSession session,RedirectAttributes attrs) {
		System.out.println("AdminController.logoutAdmin()");
		session.invalidate();
		attrs.addFlashAttribute("logout","You Have Logged Out Sucessfully");
		return"redirect:/home";
	}
	
	@GetMapping("/AdminHome")
	public String adminHome(HttpSession session,Model model) {
		if(!"ADMIN".equals(session.getAttribute("role"))) {
			return"redirect:/home";
		}
		System.out.println("AdminController.adminHome()");
		return"AdminHome";
	}
	

	
	
}
