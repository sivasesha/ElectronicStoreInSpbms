package com.nit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nit.entity.Order;
import com.nit.service.OrderServImpl;

@Controller
public class BuyController {
	
	@Autowired
	private OrderServImpl  orderService;
	
	@GetMapping("/buy")
	public String showBuyForm(@RequestParam Integer pcode,
	                          @RequestParam String pname,
	                          @RequestParam String pcompany,
	                          @RequestParam int pavailableqty,Model model) {
	                          Order order = new Order();
	                          order.setPcode(pcode);
	                          order.setPname(pname);
	                          order.setPcompany(pcompany);
	                          order.setPavailableqty(pavailableqty);
	                          model.addAttribute("order", order);
	    return"buy";
	}
	
	@PostMapping("/buy")
	public String buyProductPage(@RequestParam Integer pcode,
			@RequestParam int pqty,
		Model model
			) {
		Order order=orderService.placeOrder(pcode, pqty);
		if(order==null) {
			model.addAttribute("message","Product Not FOund Or Not Enough Stock");
			}
		model.addAttribute("orders",java.util.Collections.singletonList(order));
		model.addAttribute("message","Order Placed Sucessfully");
		return"orderMsg";
	}
	
	@GetMapping("/allorders")
	public String showOrders(Model model) {
		Iterable<Order> msg=orderService.showAllData();
		model.addAttribute("order",msg);
		return"allorders";
		
	}

}
