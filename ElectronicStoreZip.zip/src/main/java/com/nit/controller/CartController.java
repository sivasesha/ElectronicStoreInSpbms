package com.nit.controller;

import java.util.Collections;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nit.cart.Cart;
import com.nit.service.ICartService;

import jakarta.servlet.http.HttpSession;

@RequestMapping("/cart")
@Controller
public class CartController {
	
	@Autowired
	private ICartService service;
	
	@PostMapping("/add")
	public String addTocart(@RequestParam Integer cid,@RequestParam Integer pid,@RequestParam int quantity,Model model,HttpSession ses) {
		service.addtocart(cid, pid, quantity);
		
		Cart updateCart=service.getCartByCustomerId(cid);
		ses.setAttribute("cart", updateCart);
		
		return "redirect:/customerView";
	}
	@GetMapping("/getCount")
    @ResponseBody
    public Map<String, Integer> getCartCount(HttpSession session) {
        Cart cart = (Cart) session.getAttribute("cart");
        int totalQuantity = (cart != null) ? cart.getTotalQuantity() : 0;
        return Collections.singletonMap("totalQuantity", totalQuantity);
    }
	

}
