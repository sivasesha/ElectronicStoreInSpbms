package com.nit.controller;

import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nit.entity.Admin;
import com.nit.entity.Product;
import com.nit.service.IProdServImpl;

@Controller
//@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private IProdServImpl service;
	@GetMapping("/Add")
	public String addProducthome(Model model) {
		System.out.println("ProductController.addProducthome()");
		model.addAttribute("product",new Product());
		return"Add";
		
	}
	
	@PostMapping("/Add")
	public String productasAdding(@ModelAttribute("product") Product product,Model model) {
		System.out.println("ProductController.productasAdding()");
		service.addProducts(product);
		model.addAttribute("msg","Product Saved Sucessfully");
		return"prodSucess";
	}
	
	@GetMapping("/view")
	public String showProductData(Map<String, Object> map) {
		System.out.println("ProductController.showProductData()");
		Iterable<Product> prod=service.showAllproducts();
		map.put("product", prod);
		return"view";
		
	}
	
	@GetMapping("/adminHome")
	public String homeAdmin() {
		return"AdminHome";
		
	}
	
	@GetMapping("/edit")
	public String upadateFormGettingProduct(@RequestParam("pcode")int pcode,Model model){
		System.out.println("ProductController.upadateFormGettingProduct()");
		Product produ=service.getProductById(pcode);
		model.addAttribute("update", produ);
		return"update";
		
	}
	
	@PostMapping("/edit")
	public String upadtingProduct(@ModelAttribute("update")Product product,RedirectAttributes att) {
		System.out.println("ProductController.upadtingProduct()");
		String message=service.updateProduct(product);
		att.addFlashAttribute("result",message);
		return"redirect:AdminHome";
		
	}
	
	@GetMapping("/delete")
	public String deleteProduct(@RequestParam("id")int id,RedirectAttributes att) {
		System.out.println("ProductController.deleteProduct()");
		String msg=service.deleteproductById(id);
		att.addFlashAttribute("result",msg);
		return"redirect:AdminHome";
	}

}

