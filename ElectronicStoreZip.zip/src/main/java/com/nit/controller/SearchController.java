package com.nit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.nit.entity.Product;
import com.nit.model.SearchOption;
import com.nit.service.IProdServImpl;

@Controller
public class SearchController {
	
	@Autowired
	private IProdServImpl service;
	
	@GetMapping("/search")
	public String showSearchPage(Model model) {
		model.addAttribute("searchoption",new SearchOption());
		return"search";
		
		
	}
	
	@GetMapping("/searchres")
	public String searchproduct(@ModelAttribute("searchoption")SearchOption option,Model model)
	{
		List<Product> result=service.searchproducts(option);
		model.addAttribute("Products",result);
		return"searchres";
		
	}
}
