package com.nit.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.cart.Cart;
import com.nit.cart.CartItem;
import com.nit.entity.Customer;
import com.nit.entity.Product;
import com.nit.repository.CartItemRepository;
import com.nit.repository.CartRespository;
import com.nit.repository.CustomerRepository;
import com.nit.repository.ProductRepository;

@Service
public class CartServiceimpl implements ICartService {

	@Autowired
	private ProductRepository prodRepo;
	@Autowired
	private CustomerRepository custrepo;
	@Autowired
	private CartRespository cartrepo;
	
    @Override
    public void addtocart(Integer cid, Integer pid, int qty) {
        Customer customer = custrepo.findById(cid)
                .orElseThrow(() -> new IllegalArgumentException("Invalid Customer ID"));

        Cart cart = cartrepo.findByCustomerCid(cid);
        if (cart == null) {
            cart = new Cart(customer);
        }

        Product product = prodRepo.findById(pid)
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));

        // Find existing item or create a new one
        CartItem item = cart.getItems().stream()
                .filter(i -> i.getProduct().getId().equals(pid))
                .findFirst()
                .orElse(null);

        if (item == null) {
            item = new CartItem();
            item.setCart(cart);
            item.setProduct(product);
            item.setPrice(product.getPprice());
            item.setQuantity(0);  // important to initialize
            cart.getItems().add(item);
        }

        // Update quantity and subtotal
        item.setQuantity(item.getQuantity() + qty);
        item.setSubTotal(item.getPrice() * item.getQuantity());

        // Update cart totals
        cart.setTotalQuantity(cart.getItems().stream().mapToInt(i -> i.getQuantity()).sum());
        cart.setTotalPrice(cart.getItems().stream().mapToDouble(i -> i.getSubTotal()).sum());

        cartrepo.save(cart);
    }
	
	@Override
	public void removeItem(Integer pid, Integer cid) {
		Customer customer=custrepo.findById(cid).orElseThrow(()->new IllegalArgumentException("Invalid id"));
		Cart cart=cartrepo.findByCustomerCid(cid);
		if(cart!=null) {
			cart.removeItem(pid);
			cartrepo.save(cart);
		}
		
	}
	@Override
	public void decreaseCartItem(Integer cid, Integer pid, int qty) {
		Customer customer=custrepo.findById(cid).orElseThrow(()->new IllegalArgumentException("Invalid id"));
		Cart cart=cartrepo.findByCustomerCid(cid);
		if(cart!=null) {
			Optional<CartItem> itemsopt=cart.getItems().stream().filter(i->i.getProduct().getId().equals(pid)).findFirst();
			
			if(itemsopt.isPresent()) {
				CartItem items=itemsopt.get();
				int newqty=items.getQuantity()-qty;
				if(newqty<=0) {
					cart.removeItem(pid);
				}else {
					cartrepo.save(cart);
				}
			}
		}
		
	}
	
	@Override
	public Cart getCartByCustomerId(Integer cid) {
		Customer customer=custrepo.findById(cid).orElseThrow(()->new IllegalArgumentException("Invalid id"));
		Cart cart=cartrepo.findById(cid).orElseGet(()->new Cart(customer));
		if(cart!=null) {
			cart=new Cart(customer);
			cart.setTotalPrice(0.0);
			cart.setTotalQuantity(0);
		}
		return cart;
	}


}
