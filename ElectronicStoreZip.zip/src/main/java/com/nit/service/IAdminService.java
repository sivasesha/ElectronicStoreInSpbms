package com.nit.service;

import java.util.Optional;

import com.nit.entity.Admin;

public interface IAdminService {
     Optional<Admin> validateAdmin(String uname,String pwrd);
}
