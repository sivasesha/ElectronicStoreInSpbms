package com.nit.service;

import java.util.Optional;

import com.nit.entity.Customer;
import com.nit.entity.Product;

public interface ICustomerService {
	
	public String RegisterCustomer(Customer cust);
	
	public Optional<Customer> validateUser(String uname,String pwrd);
	
	public Iterable<Product> showAllData();
	
	public Product getProductByCode(Integer pcode);

	public Customer getCustomerByUsername(String uname);
}
