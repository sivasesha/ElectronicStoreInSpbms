package com.nit.service;

import com.nit.entity.Order;

public interface IOrderService {
	public Order placeOrder(Integer pcode,int qty);

	public Iterable<Order> showAllData();
}
