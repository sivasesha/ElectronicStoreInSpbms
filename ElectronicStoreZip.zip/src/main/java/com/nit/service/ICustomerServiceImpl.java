package com.nit.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.entity.Customer;
import com.nit.entity.Product;
import com.nit.repository.CustomerRepository;
import com.nit.repository.ProductRepository;

@Service
public class ICustomerServiceImpl implements ICustomerService {

	@Autowired
	private CustomerRepository repo;
	
	@Autowired
	private ProductRepository productrepo;
	

	
	
	public ICustomerServiceImpl() {
		System.out.println("ICustomerServiceImpl.ICustomerServiceImpl()");
	}
	public String RegisterCustomer(Customer cust) {
		repo.save(cust);
		return "Customer registered::"+cust.getCid();
	}
	
	@Override
	public Iterable<Product> showAllData() {
		return productrepo.findAll();
	}
	@Override
	public Optional<Customer> validateUser(String uname, String pwrd) {
		return repo.findByCunameAndCpwrd(uname, pwrd);
	}
	
	@Override
	public Product getProductByCode(Integer pcode) {
		
		return productrepo.findByPcode(pcode);
	}
	
	@Override
	public Customer getCustomerByUsername(String uname) {
		
		return repo.findByCuname(uname).orElseThrow(()->new IllegalArgumentException("Invalid uname"));
	}

}
