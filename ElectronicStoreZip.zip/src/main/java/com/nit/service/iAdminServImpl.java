package com.nit.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.entity.Admin;
import com.nit.repository.AdminRepository;

@Service
public class iAdminServImpl implements IAdminService {

	@Autowired
	private AdminRepository repo;
	@Override
	public Optional<Admin> validateAdmin(String uname, String pwrd) {
		 return repo.findByUnameAndPwrd(uname, pwrd);
	}

}
