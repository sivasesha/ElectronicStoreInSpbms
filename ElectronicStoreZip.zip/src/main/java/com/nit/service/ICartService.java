package com.nit.service;

import com.nit.cart.Cart;

public interface ICartService {
	 
	public void addtocart(Integer cid,Integer pid,int qty);

	public void decreaseCartItem(Integer cid,Integer pid,int qty);
  
	public void removeItem(Integer pid,Integer cid);
	
	public Cart getCartByCustomerId(Integer cid);

}
