package com.nit.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.entity.Product;
import com.nit.model.SearchOption;
import com.nit.repository.ProductRepository;

@Service
public class IProdServImpl implements IProductService {

	@Autowired
	private ProductRepository repo;
	@Override
	public String addProducts(Product prod) {
		repo.save(prod);
		return null;
	}
	@Override
	public Iterable<Product> showAllproducts() {
		return  repo.findAll();
		
	}
	@Override
	public Product getProductById(int pcode) {
		Product product1=repo.findById(pcode).orElseThrow(()->new IllegalArgumentException("Invalid Pcode"));
		return product1;
	}
	@Override
	public String updateProduct(Product product) {
		return"Product Is Updated Sucessfully::"+repo.save(product).getPcode();
		
	}
	@Override
	public String deleteproductById(int id) {
		repo.deleteById(id);
		return id+"This Product Is Deleted";
	}
	@Override
	public List<Product> searchproducts(SearchOption option) {
		Iterable<Product> products=showAllproducts();
		
		List<Product> prod=new ArrayList<>();
		products.forEach(prod::add);
		return prod.stream().
				filter(p->option.getName()==null||p.getPname().toLowerCase().contains(option.getName().toLowerCase()))
				.filter(p->option.getCompany()==null||p.getPcompany().toLowerCase().contains(option.getCompany().toLowerCase()))
				.filter(p->option.getMinprice()==null||p.getPprice()>=option.getMinprice())
				.filter(p->option.getMaxprice()==null||p.getPprice()>=option.getMaxprice())
				.collect(Collectors.toList());
	}
	
	

}
