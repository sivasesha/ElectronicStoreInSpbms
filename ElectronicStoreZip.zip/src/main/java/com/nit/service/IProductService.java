package com.nit.service;

import java.util.List;

import com.nit.entity.Product;
import com.nit.model.SearchOption;

public interface IProductService  {

	public String addProducts(Product prod);
	
	public Iterable<Product> showAllproducts();
	
	public Product getProductById(int pcode);
	
	public String updateProduct(Product product);
	
	public String deleteproductById(int id);
	
	public List<Product> searchproducts(SearchOption option);
}
