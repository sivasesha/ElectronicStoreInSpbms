package com.nit.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.entity.Order;
import com.nit.entity.Product;
import com.nit.repository.OrderRepository;
import com.nit.repository.ProductRepository;

@Service
public class OrderServImpl implements IOrderService {

	
	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired
	private ProductRepository productRepo;
	@Override
	public Order placeOrder(Integer pcode, int qty) {
		Product product=productRepo.findByPcode(pcode);
		if(product==null) {
			return null;
		}else if(product.getPqty() <qty){
			return null	;
		}
		Order order=new Order();
		order.setPcode(product.getPcode());
		order.setPname(product.getPname());
		order.setPcompany(product.getPcompany());
		order.setPprice(product.getPprice());
		order.setPqty(qty);
		order.setTotalAmount(product.getPprice()*qty);
		order.setOrdereddate(LocalDate.now());
		orderRepo.save(order);
		
		product.setPqty(product.getPqty()-qty);
		productRepo.save(product);
		return order;
	}
	@Override
	public Iterable<Order> showAllData() {
		return orderRepo.findAll();
		 
	}

}
